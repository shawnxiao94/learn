import Root from './Root'
/**
 * @see 全局组件
 */
/**
 * 面包屑组件
 */
import CRouteCrumb from '@/components/RouteCrumb/store'
/**
 * @end 全局组件
 */

export default {
    Root,
    /**
     * @see 全局组件
     */
    CRouteCrumb
    /**
     * @end 全局组件
     */
}

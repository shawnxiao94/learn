/**
 * 前端MOCK API数据
 */
/**
 * 全局API
 */
import './common'
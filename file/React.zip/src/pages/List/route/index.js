import config from './config'
import formatRouter from '@/router/common'
const Router = () => {
    return formatRouter(config)
}
export default Router
import config from './config'
import formatRouter from './common'
const Router = () => {
    return formatRouter(config)
}
export default Router

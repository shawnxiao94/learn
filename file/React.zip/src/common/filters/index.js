// 常用方法
import * as commons from './common'
// 状态
import * as status from './status'
export default {
    ...commons,
    ...status
}

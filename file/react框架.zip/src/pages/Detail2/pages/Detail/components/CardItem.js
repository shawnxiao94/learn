import React, { Component } from 'react'
import { Card } from 'antd'
class CardItem extends Component {
    render() {
        return (
            <Card title='Card title' bordered={false}>
                <p>子路由详情</p>
                <p>子路由详情</p>
                <p>子路由详情</p>
            </Card>
        )
    }
}
export default CardItem
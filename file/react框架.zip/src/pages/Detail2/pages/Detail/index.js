import React, { Component } from 'react'
class Detail extends Component {
    render() {
        return (
            <div>
                212121212
            </div>
        )
    }
}
export default Detail
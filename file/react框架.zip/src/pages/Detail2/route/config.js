/**
 * 页面子路由配置
 */
import Loadable from 'react-loadable'
import DelayLoading from '@/components/DelayLoading'

const Detail = Loadable({ loader: () => import(/* webpackChunkName: "Detail2" */ '@/pages/Detail2/pages/Detail'), loading: DelayLoading, delay: 3000 })

export default [{
    name: '子页面',
    path: '/list/detail2/detail',
    icon: 'home',
    component: Detail
}]

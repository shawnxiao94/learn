import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import CardItem from './components/CardItem'
import { Row, Col } from 'antd'
import RouteCrumb from '@/components/RouteCrumb'
import SubRoute from './route'
class Detail2 extends Component {
    render() {
        return (
            <div>
                <RouteCrumb />
                <div style={{ 'display': (this.props.location.pathname !== '/list/detail2') ? 'none' : 'block' }}>
                    <Link
                        to={{
                            pathname: '/list/detail2/detail'
                        }}
                    >
                    详情
                    </Link>
                    <Row gutter={16} style={{ 'margin-top': '16px' }}>
                        <Col span={8}>
                            <CardItem />
                        </Col>
                        <Col span={8}>
                            <CardItem />
                        </Col>
                        <Col span={8}>
                            <CardItem />
                        </Col>
                    </Row>
                </div>
                <SubRoute />
            </div>
        )
    }
}
export default Detail2
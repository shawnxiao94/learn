import React, { Component } from 'react'
import CardItem from './components/CardItem'
import { Row, Col } from 'antd'
import Search from '@/pages/Home/components/Search'
class Detail extends Component {
    render() {
        return (
            <div>
                <Search />
                <Row gutter={16} style={{ 'margin-top': '16px' }}>
                    <Col span={8}>
                        <CardItem />
                    </Col>
                    <Col span={8}>
                        <CardItem />
                    </Col>
                    <Col span={8}>
                        <CardItem />
                    </Col>
                </Row>
            </div>
        )
    }
}
export default Detail
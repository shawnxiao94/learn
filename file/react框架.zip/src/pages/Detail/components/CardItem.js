import React, { Component } from 'react'
import { Card } from 'antd'
class CardItem extends Component {
    render() {
        return (
            <Card title='Card title' bordered={false}>
                <p>Detail</p>
                <p>Detail</p>
                <p>Detail</p>
            </Card>
        )
    }
}
export default CardItem
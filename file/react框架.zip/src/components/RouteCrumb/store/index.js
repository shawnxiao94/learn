import { observable, action, configure } from 'mobx'
configure({ enforceActions: 'observed' })
class RouteCrumb {
    @observable crumbs = []
    @action setCrumbs = crumbs => {
        this.crumbs = crumbs
    }
}

export default new RouteCrumb()

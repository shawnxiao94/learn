import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { Breadcrumb } from 'antd'
import { inject, observer } from 'mobx-react'
import router from '@/router/config'
import './index.less'

@withRouter
@inject('CRouteCrumb')
@observer
class RouteCrumb extends Component {
    state = {
        crumbs: []
    };
    componentWillUnmount() {
        debugger
    }
    componentWillReceiveProps(nextProps) {
        debugger
        if (this.props.location.pathname !== nextProps.location.pathname) {
            if (this.state.crumbs.some(item => item.key === nextProps.location.pathname)) {
                this.setState({ activeKey: nextProps.location.pathname })
            } else {
                let nextRoute
                const filterRouters = (_router, _parentPath = '') => {
                    _router.forEach(item => {
                        if (item.hidden) {
                            return
                        }
                        let _subRoute = item.subRoute && item.subRoute.filter(subItem => !subItem.hidden)
                        if (_subRoute && _subRoute.length) {
                            filterRouters(_subRoute, item.path)
                        } else {
                            if (_parentPath + item.path === nextProps.location.pathname) {
                                nextRoute = item
                            }
                        }
                    })
                }
                filterRouters(router)
                if (nextRoute) {
                    this.add({
                        title: nextRoute.name,
                        key: nextProps.location.pathname
                    })
                }
            }
        }
    }
    /**
     * 添加路由
     */
    add({ title = '', key }) {
        const { crumbs } = this.state
        crumbs.push({ title: title, key: key })
        this.setState({ crumbs })
    }
    /**
     * 移动路由
     */
    move() {
    }
    render() {
        // return this.state.crumbs.length ? (
        //     <div className='c-route-crumb'>
        //         <Breadcrumb>
        //             {this.state.crumbs.map((item, index) => (
        //                 <Breadcrumb.Item key={index}>{item.path}</Breadcrumb.Item>
        //             ))}
        //         </Breadcrumb>
        //     </div>
        // ) : ''
        return (
            <div className='c-route-crumb'>
                <Breadcrumb>
                    <Breadcrumb.Item>列表</Breadcrumb.Item>
                    <Breadcrumb.Item>详情</Breadcrumb.Item>
                </Breadcrumb>
            </div>
        )
    }
}

export default RouteCrumb

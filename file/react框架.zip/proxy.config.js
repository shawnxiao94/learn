module.exports = {
    '/mock': {
        target: 'http://10.100.58.5:8080',
        secure: false,
        changeOrigin: true
    }
}

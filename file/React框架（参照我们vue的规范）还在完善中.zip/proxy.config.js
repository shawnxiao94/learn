module.exports = {
    '/mock': {
        target: 'https://www.easy-mock.com',
        secure: false,
        changeOrigin: true
    }
}
